
function onButton(figura: "kolo"|"kwadrat"|"prostokat"|"trojkat"){
    switch(figura){
        case "kolo":
            kolo();
            break;
        case "kwadrat":
            kwadrat();
        break;
        case "prostokat":
            prostokat();
        break;
        case "trojkat":
            trojkat();
        break;
    }

function kolo(){
    let prom = prompt("podaj promien");
    if(prom != null){
        let promien = parseFloat(prom);
        const pi = 3.14;
        alert("Pole = "+((promien*promien)*pi));
        }else{
            alert("noway");
        }
    }
    
}
function kwadrat(){
    let val = prompt("podaj bok");
    if(val != null){
        let bok = parseFloat(val);
        alert("Pole = "+(bok*bok));
    }else{
        alert("noway");
    }
}
function prostokat(){
    let val1 = prompt("podaj bok a");
    let val2 = prompt("podaj bok b");
    if(val1 != null && val2 != null){
        let bokA = parseFloat(val1);
        let bokB = parseFloat(val2);
        alert("Pole = "+(bokA*bokB));
    }else{
        alert("noway");
    }
}
function trojkat(){
    let val1 = prompt("podaj bok a");
    let val2 = prompt("podaj bok b");
    let val3 = prompt("podaj bok c");
    if(val1 != null && val2 != null && val3 != null){
        let bokA = parseFloat(val1);
        let bokB = parseFloat(val2);
        let bokC = parseFloat(val3);
        if(bokA < bokB+bokC && bokB < bokA+bokC && bokC < bokB+bokA ){
            let obw = bokA+bokB+bokC;
            alert("Pole = "+(Math.sqrt(obw*(obw-bokA)*(obw-bokB)*(obw-bokC))));
        }else{
            alert("Trojkat nie istnieje");
        }
    }else{
        alert("noway");
    }
}